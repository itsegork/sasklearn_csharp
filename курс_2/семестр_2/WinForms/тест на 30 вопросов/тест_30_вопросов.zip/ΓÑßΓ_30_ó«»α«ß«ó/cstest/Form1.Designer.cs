﻿namespace cstest
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.button2 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.tabPage10 = new System.Windows.Forms.TabPage();
            this.tabPage11 = new System.Windows.Forms.TabPage();
            this.tabPage12 = new System.Windows.Forms.TabPage();
            this.tabPage13 = new System.Windows.Forms.TabPage();
            this.tabPage14 = new System.Windows.Forms.TabPage();
            this.tabPage15 = new System.Windows.Forms.TabPage();
            this.tabPage16 = new System.Windows.Forms.TabPage();
            this.tabPage17 = new System.Windows.Forms.TabPage();
            this.tabPage18 = new System.Windows.Forms.TabPage();
            this.tabPage19 = new System.Windows.Forms.TabPage();
            this.tabPage20 = new System.Windows.Forms.TabPage();
            this.tabPage21 = new System.Windows.Forms.TabPage();
            this.tabPage22 = new System.Windows.Forms.TabPage();
            this.tabPage23 = new System.Windows.Forms.TabPage();
            this.tabPage24 = new System.Windows.Forms.TabPage();
            this.tabPage25 = new System.Windows.Forms.TabPage();
            this.tabPage26 = new System.Windows.Forms.TabPage();
            this.tabPage27 = new System.Windows.Forms.TabPage();
            this.tabPage28 = new System.Windows.Forms.TabPage();
            this.tabPage29 = new System.Windows.Forms.TabPage();
            this.tabPage30 = new System.Windows.Forms.TabPage();
            this.tabPage31 = new System.Windows.Forms.TabPage();
            this.tabPage32 = new System.Windows.Forms.TabPage();
            this.button3 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.radioButton7 = new System.Windows.Forms.RadioButton();
            this.radioButton8 = new System.Windows.Forms.RadioButton();
            this.button4 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.radioButton10 = new System.Windows.Forms.RadioButton();
            this.radioButton11 = new System.Windows.Forms.RadioButton();
            this.radioButton12 = new System.Windows.Forms.RadioButton();
            this.button5 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.radioButton9 = new System.Windows.Forms.RadioButton();
            this.radioButton13 = new System.Windows.Forms.RadioButton();
            this.radioButton14 = new System.Windows.Forms.RadioButton();
            this.button6 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.radioButton15 = new System.Windows.Forms.RadioButton();
            this.radioButton16 = new System.Windows.Forms.RadioButton();
            this.radioButton17 = new System.Windows.Forms.RadioButton();
            this.button7 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.radioButton18 = new System.Windows.Forms.RadioButton();
            this.radioButton19 = new System.Windows.Forms.RadioButton();
            this.radioButton20 = new System.Windows.Forms.RadioButton();
            this.radioButton21 = new System.Windows.Forms.RadioButton();
            this.radioButton22 = new System.Windows.Forms.RadioButton();
            this.button8 = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.radioButton23 = new System.Windows.Forms.RadioButton();
            this.radioButton24 = new System.Windows.Forms.RadioButton();
            this.radioButton25 = new System.Windows.Forms.RadioButton();
            this.button9 = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.radioButton27 = new System.Windows.Forms.RadioButton();
            this.radioButton28 = new System.Windows.Forms.RadioButton();
            this.radioButton29 = new System.Windows.Forms.RadioButton();
            this.button10 = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.radioButton26 = new System.Windows.Forms.RadioButton();
            this.radioButton30 = new System.Windows.Forms.RadioButton();
            this.radioButton31 = new System.Windows.Forms.RadioButton();
            this.button11 = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.radioButton32 = new System.Windows.Forms.RadioButton();
            this.radioButton33 = new System.Windows.Forms.RadioButton();
            this.radioButton34 = new System.Windows.Forms.RadioButton();
            this.button12 = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.radioButton35 = new System.Windows.Forms.RadioButton();
            this.radioButton36 = new System.Windows.Forms.RadioButton();
            this.radioButton37 = new System.Windows.Forms.RadioButton();
            this.label13 = new System.Windows.Forms.Label();
            this.button13 = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.radioButton38 = new System.Windows.Forms.RadioButton();
            this.radioButton39 = new System.Windows.Forms.RadioButton();
            this.radioButton40 = new System.Windows.Forms.RadioButton();
            this.button14 = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.radioButton41 = new System.Windows.Forms.RadioButton();
            this.radioButton42 = new System.Windows.Forms.RadioButton();
            this.radioButton43 = new System.Windows.Forms.RadioButton();
            this.button15 = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.radioButton44 = new System.Windows.Forms.RadioButton();
            this.radioButton45 = new System.Windows.Forms.RadioButton();
            this.radioButton46 = new System.Windows.Forms.RadioButton();
            this.button16 = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.radioButton47 = new System.Windows.Forms.RadioButton();
            this.radioButton48 = new System.Windows.Forms.RadioButton();
            this.radioButton49 = new System.Windows.Forms.RadioButton();
            this.label18 = new System.Windows.Forms.Label();
            this.button17 = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.radioButton50 = new System.Windows.Forms.RadioButton();
            this.radioButton51 = new System.Windows.Forms.RadioButton();
            this.radioButton52 = new System.Windows.Forms.RadioButton();
            this.button18 = new System.Windows.Forms.Button();
            this.label20 = new System.Windows.Forms.Label();
            this.radioButton53 = new System.Windows.Forms.RadioButton();
            this.radioButton54 = new System.Windows.Forms.RadioButton();
            this.radioButton55 = new System.Windows.Forms.RadioButton();
            this.button19 = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.radioButton56 = new System.Windows.Forms.RadioButton();
            this.radioButton57 = new System.Windows.Forms.RadioButton();
            this.radioButton58 = new System.Windows.Forms.RadioButton();
            this.button20 = new System.Windows.Forms.Button();
            this.label22 = new System.Windows.Forms.Label();
            this.radioButton59 = new System.Windows.Forms.RadioButton();
            this.radioButton60 = new System.Windows.Forms.RadioButton();
            this.radioButton61 = new System.Windows.Forms.RadioButton();
            this.button21 = new System.Windows.Forms.Button();
            this.label23 = new System.Windows.Forms.Label();
            this.radioButton62 = new System.Windows.Forms.RadioButton();
            this.radioButton63 = new System.Windows.Forms.RadioButton();
            this.radioButton64 = new System.Windows.Forms.RadioButton();
            this.button22 = new System.Windows.Forms.Button();
            this.label24 = new System.Windows.Forms.Label();
            this.radioButton65 = new System.Windows.Forms.RadioButton();
            this.radioButton66 = new System.Windows.Forms.RadioButton();
            this.radioButton67 = new System.Windows.Forms.RadioButton();
            this.button23 = new System.Windows.Forms.Button();
            this.label25 = new System.Windows.Forms.Label();
            this.radioButton68 = new System.Windows.Forms.RadioButton();
            this.radioButton69 = new System.Windows.Forms.RadioButton();
            this.radioButton70 = new System.Windows.Forms.RadioButton();
            this.button24 = new System.Windows.Forms.Button();
            this.label26 = new System.Windows.Forms.Label();
            this.radioButton71 = new System.Windows.Forms.RadioButton();
            this.radioButton72 = new System.Windows.Forms.RadioButton();
            this.radioButton73 = new System.Windows.Forms.RadioButton();
            this.button25 = new System.Windows.Forms.Button();
            this.label27 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button26 = new System.Windows.Forms.Button();
            this.label28 = new System.Windows.Forms.Label();
            this.radioButton74 = new System.Windows.Forms.RadioButton();
            this.radioButton75 = new System.Windows.Forms.RadioButton();
            this.radioButton76 = new System.Windows.Forms.RadioButton();
            this.button27 = new System.Windows.Forms.Button();
            this.label29 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.button28 = new System.Windows.Forms.Button();
            this.label30 = new System.Windows.Forms.Label();
            this.radioButton77 = new System.Windows.Forms.RadioButton();
            this.radioButton78 = new System.Windows.Forms.RadioButton();
            this.radioButton79 = new System.Windows.Forms.RadioButton();
            this.button29 = new System.Windows.Forms.Button();
            this.label31 = new System.Windows.Forms.Label();
            this.radioButton80 = new System.Windows.Forms.RadioButton();
            this.radioButton81 = new System.Windows.Forms.RadioButton();
            this.radioButton82 = new System.Windows.Forms.RadioButton();
            this.button30 = new System.Windows.Forms.Button();
            this.label32 = new System.Windows.Forms.Label();
            this.radioButton83 = new System.Windows.Forms.RadioButton();
            this.radioButton84 = new System.Windows.Forms.RadioButton();
            this.radioButton85 = new System.Windows.Forms.RadioButton();
            this.button31 = new System.Windows.Forms.Button();
            this.label33 = new System.Windows.Forms.Label();
            this.radioButton86 = new System.Windows.Forms.RadioButton();
            this.radioButton87 = new System.Windows.Forms.RadioButton();
            this.radioButton88 = new System.Windows.Forms.RadioButton();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.button32 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.tabPage8.SuspendLayout();
            this.tabPage9.SuspendLayout();
            this.tabPage10.SuspendLayout();
            this.tabPage11.SuspendLayout();
            this.tabPage12.SuspendLayout();
            this.tabPage13.SuspendLayout();
            this.tabPage14.SuspendLayout();
            this.tabPage15.SuspendLayout();
            this.tabPage16.SuspendLayout();
            this.tabPage17.SuspendLayout();
            this.tabPage18.SuspendLayout();
            this.tabPage19.SuspendLayout();
            this.tabPage20.SuspendLayout();
            this.tabPage21.SuspendLayout();
            this.tabPage22.SuspendLayout();
            this.tabPage23.SuspendLayout();
            this.tabPage24.SuspendLayout();
            this.tabPage25.SuspendLayout();
            this.tabPage26.SuspendLayout();
            this.tabPage27.SuspendLayout();
            this.tabPage28.SuspendLayout();
            this.tabPage29.SuspendLayout();
            this.tabPage30.SuspendLayout();
            this.tabPage31.SuspendLayout();
            this.tabPage32.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Controls.Add(this.tabPage7);
            this.tabControl1.Controls.Add(this.tabPage8);
            this.tabControl1.Controls.Add(this.tabPage9);
            this.tabControl1.Controls.Add(this.tabPage10);
            this.tabControl1.Controls.Add(this.tabPage11);
            this.tabControl1.Controls.Add(this.tabPage12);
            this.tabControl1.Controls.Add(this.tabPage13);
            this.tabControl1.Controls.Add(this.tabPage14);
            this.tabControl1.Controls.Add(this.tabPage15);
            this.tabControl1.Controls.Add(this.tabPage16);
            this.tabControl1.Controls.Add(this.tabPage17);
            this.tabControl1.Controls.Add(this.tabPage18);
            this.tabControl1.Controls.Add(this.tabPage19);
            this.tabControl1.Controls.Add(this.tabPage20);
            this.tabControl1.Controls.Add(this.tabPage21);
            this.tabControl1.Controls.Add(this.tabPage22);
            this.tabControl1.Controls.Add(this.tabPage23);
            this.tabControl1.Controls.Add(this.tabPage24);
            this.tabControl1.Controls.Add(this.tabPage25);
            this.tabControl1.Controls.Add(this.tabPage26);
            this.tabControl1.Controls.Add(this.tabPage27);
            this.tabControl1.Controls.Add(this.tabPage28);
            this.tabControl1.Controls.Add(this.tabPage29);
            this.tabControl1.Controls.Add(this.tabPage30);
            this.tabControl1.Controls.Add(this.tabPage31);
            this.tabControl1.Controls.Add(this.tabPage32);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(530, 605);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Location = new System.Drawing.Point(4, 29);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(522, 572);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Заголовок";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(128, 236);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(256, 39);
            this.button1.TabIndex = 1;
            this.button1.Text = "Приступить";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(109, 198);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(298, 35);
            this.label1.TabIndex = 0;
            this.label1.Text = "Тестирование по ЯП C#\r\n";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.button2);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.radioButton4);
            this.tabPage2.Controls.Add(this.radioButton3);
            this.tabPage2.Controls.Add(this.radioButton2);
            this.tabPage2.Controls.Add(this.radioButton1);
            this.tabPage2.Location = new System.Drawing.Point(4, 29);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(522, 572);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "1";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(353, 499);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(140, 38);
            this.button2.TabIndex = 5;
            this.button2.Text = "Далее";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(54, 164);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(359, 20);
            this.label2.TabIndex = 4;
            this.label2.Text = "Какой символ обозначает комментарий в C#?";
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(58, 296);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(52, 24);
            this.radioButton4.TabIndex = 3;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "##";
            this.radioButton4.UseVisualStyleBackColor = true;
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(58, 266);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(44, 24);
            this.radioButton3.TabIndex = 2;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "--";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(58, 236);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(38, 24);
            this.radioButton2.TabIndex = 1;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "/";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(58, 206);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(42, 24);
            this.radioButton1.TabIndex = 0;
            this.radioButton1.Text = "//";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.button3);
            this.tabPage3.Controls.Add(this.label3);
            this.tabPage3.Controls.Add(this.radioButton5);
            this.tabPage3.Controls.Add(this.radioButton6);
            this.tabPage3.Controls.Add(this.radioButton7);
            this.tabPage3.Controls.Add(this.radioButton8);
            this.tabPage3.Location = new System.Drawing.Point(4, 29);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(522, 572);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "2";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.button4);
            this.tabPage4.Controls.Add(this.label4);
            this.tabPage4.Controls.Add(this.radioButton10);
            this.tabPage4.Controls.Add(this.radioButton11);
            this.tabPage4.Controls.Add(this.radioButton12);
            this.tabPage4.Location = new System.Drawing.Point(4, 29);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(522, 572);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "3";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.button5);
            this.tabPage5.Controls.Add(this.label5);
            this.tabPage5.Controls.Add(this.radioButton9);
            this.tabPage5.Controls.Add(this.radioButton13);
            this.tabPage5.Controls.Add(this.radioButton14);
            this.tabPage5.Location = new System.Drawing.Point(4, 29);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(522, 572);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "4";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.button6);
            this.tabPage6.Controls.Add(this.label6);
            this.tabPage6.Controls.Add(this.radioButton15);
            this.tabPage6.Controls.Add(this.radioButton16);
            this.tabPage6.Controls.Add(this.radioButton17);
            this.tabPage6.Location = new System.Drawing.Point(4, 29);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(522, 572);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "5";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.radioButton21);
            this.tabPage7.Controls.Add(this.button7);
            this.tabPage7.Controls.Add(this.label7);
            this.tabPage7.Controls.Add(this.radioButton18);
            this.tabPage7.Controls.Add(this.radioButton19);
            this.tabPage7.Controls.Add(this.radioButton20);
            this.tabPage7.Location = new System.Drawing.Point(4, 29);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Size = new System.Drawing.Size(522, 572);
            this.tabPage7.TabIndex = 6;
            this.tabPage7.Text = "6";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.radioButton22);
            this.tabPage8.Controls.Add(this.button8);
            this.tabPage8.Controls.Add(this.label8);
            this.tabPage8.Controls.Add(this.radioButton23);
            this.tabPage8.Controls.Add(this.radioButton24);
            this.tabPage8.Controls.Add(this.radioButton25);
            this.tabPage8.Location = new System.Drawing.Point(4, 29);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Size = new System.Drawing.Size(522, 572);
            this.tabPage8.TabIndex = 7;
            this.tabPage8.Text = "7";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // tabPage9
            // 
            this.tabPage9.Controls.Add(this.button9);
            this.tabPage9.Controls.Add(this.label9);
            this.tabPage9.Controls.Add(this.radioButton27);
            this.tabPage9.Controls.Add(this.radioButton28);
            this.tabPage9.Controls.Add(this.radioButton29);
            this.tabPage9.Location = new System.Drawing.Point(4, 29);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Size = new System.Drawing.Size(522, 572);
            this.tabPage9.TabIndex = 8;
            this.tabPage9.Text = "8";
            this.tabPage9.UseVisualStyleBackColor = true;
            // 
            // tabPage10
            // 
            this.tabPage10.Controls.Add(this.button10);
            this.tabPage10.Controls.Add(this.label10);
            this.tabPage10.Controls.Add(this.radioButton26);
            this.tabPage10.Controls.Add(this.radioButton30);
            this.tabPage10.Controls.Add(this.radioButton31);
            this.tabPage10.Location = new System.Drawing.Point(4, 29);
            this.tabPage10.Name = "tabPage10";
            this.tabPage10.Size = new System.Drawing.Size(522, 572);
            this.tabPage10.TabIndex = 9;
            this.tabPage10.Text = "9";
            this.tabPage10.UseVisualStyleBackColor = true;
            // 
            // tabPage11
            // 
            this.tabPage11.Controls.Add(this.button11);
            this.tabPage11.Controls.Add(this.label11);
            this.tabPage11.Controls.Add(this.radioButton32);
            this.tabPage11.Controls.Add(this.radioButton33);
            this.tabPage11.Controls.Add(this.radioButton34);
            this.tabPage11.Location = new System.Drawing.Point(4, 29);
            this.tabPage11.Name = "tabPage11";
            this.tabPage11.Size = new System.Drawing.Size(522, 572);
            this.tabPage11.TabIndex = 10;
            this.tabPage11.Text = "10";
            this.tabPage11.UseVisualStyleBackColor = true;
            // 
            // tabPage12
            // 
            this.tabPage12.Controls.Add(this.label13);
            this.tabPage12.Controls.Add(this.button12);
            this.tabPage12.Controls.Add(this.label12);
            this.tabPage12.Controls.Add(this.radioButton35);
            this.tabPage12.Controls.Add(this.radioButton36);
            this.tabPage12.Controls.Add(this.radioButton37);
            this.tabPage12.Location = new System.Drawing.Point(4, 29);
            this.tabPage12.Name = "tabPage12";
            this.tabPage12.Size = new System.Drawing.Size(522, 572);
            this.tabPage12.TabIndex = 11;
            this.tabPage12.Text = "11";
            this.tabPage12.UseVisualStyleBackColor = true;
            // 
            // tabPage13
            // 
            this.tabPage13.Controls.Add(this.button13);
            this.tabPage13.Controls.Add(this.label15);
            this.tabPage13.Controls.Add(this.radioButton38);
            this.tabPage13.Controls.Add(this.radioButton39);
            this.tabPage13.Controls.Add(this.radioButton40);
            this.tabPage13.Location = new System.Drawing.Point(4, 29);
            this.tabPage13.Name = "tabPage13";
            this.tabPage13.Size = new System.Drawing.Size(522, 572);
            this.tabPage13.TabIndex = 12;
            this.tabPage13.Text = "12";
            this.tabPage13.UseVisualStyleBackColor = true;
            // 
            // tabPage14
            // 
            this.tabPage14.Controls.Add(this.button14);
            this.tabPage14.Controls.Add(this.label14);
            this.tabPage14.Controls.Add(this.radioButton41);
            this.tabPage14.Controls.Add(this.radioButton42);
            this.tabPage14.Controls.Add(this.radioButton43);
            this.tabPage14.Location = new System.Drawing.Point(4, 29);
            this.tabPage14.Name = "tabPage14";
            this.tabPage14.Size = new System.Drawing.Size(522, 572);
            this.tabPage14.TabIndex = 13;
            this.tabPage14.Text = "13";
            this.tabPage14.UseVisualStyleBackColor = true;
            // 
            // tabPage15
            // 
            this.tabPage15.Controls.Add(this.button15);
            this.tabPage15.Controls.Add(this.label16);
            this.tabPage15.Controls.Add(this.radioButton44);
            this.tabPage15.Controls.Add(this.radioButton45);
            this.tabPage15.Controls.Add(this.radioButton46);
            this.tabPage15.Location = new System.Drawing.Point(4, 29);
            this.tabPage15.Name = "tabPage15";
            this.tabPage15.Size = new System.Drawing.Size(522, 572);
            this.tabPage15.TabIndex = 14;
            this.tabPage15.Text = "14";
            this.tabPage15.UseVisualStyleBackColor = true;
            // 
            // tabPage16
            // 
            this.tabPage16.Controls.Add(this.label18);
            this.tabPage16.Controls.Add(this.button16);
            this.tabPage16.Controls.Add(this.label17);
            this.tabPage16.Controls.Add(this.radioButton47);
            this.tabPage16.Controls.Add(this.radioButton48);
            this.tabPage16.Controls.Add(this.radioButton49);
            this.tabPage16.Location = new System.Drawing.Point(4, 29);
            this.tabPage16.Name = "tabPage16";
            this.tabPage16.Size = new System.Drawing.Size(522, 572);
            this.tabPage16.TabIndex = 15;
            this.tabPage16.Text = "15";
            this.tabPage16.UseVisualStyleBackColor = true;
            // 
            // tabPage17
            // 
            this.tabPage17.Controls.Add(this.button17);
            this.tabPage17.Controls.Add(this.label19);
            this.tabPage17.Controls.Add(this.radioButton50);
            this.tabPage17.Controls.Add(this.radioButton51);
            this.tabPage17.Controls.Add(this.radioButton52);
            this.tabPage17.Location = new System.Drawing.Point(4, 29);
            this.tabPage17.Name = "tabPage17";
            this.tabPage17.Size = new System.Drawing.Size(522, 572);
            this.tabPage17.TabIndex = 16;
            this.tabPage17.Text = "16";
            this.tabPage17.UseVisualStyleBackColor = true;
            // 
            // tabPage18
            // 
            this.tabPage18.Controls.Add(this.button18);
            this.tabPage18.Controls.Add(this.label20);
            this.tabPage18.Controls.Add(this.radioButton53);
            this.tabPage18.Controls.Add(this.radioButton54);
            this.tabPage18.Controls.Add(this.radioButton55);
            this.tabPage18.Location = new System.Drawing.Point(4, 29);
            this.tabPage18.Name = "tabPage18";
            this.tabPage18.Size = new System.Drawing.Size(522, 572);
            this.tabPage18.TabIndex = 17;
            this.tabPage18.Text = "17";
            this.tabPage18.UseVisualStyleBackColor = true;
            // 
            // tabPage19
            // 
            this.tabPage19.Controls.Add(this.button19);
            this.tabPage19.Controls.Add(this.label21);
            this.tabPage19.Controls.Add(this.radioButton56);
            this.tabPage19.Controls.Add(this.radioButton57);
            this.tabPage19.Controls.Add(this.radioButton58);
            this.tabPage19.Location = new System.Drawing.Point(4, 29);
            this.tabPage19.Name = "tabPage19";
            this.tabPage19.Size = new System.Drawing.Size(522, 572);
            this.tabPage19.TabIndex = 18;
            this.tabPage19.Text = "18";
            this.tabPage19.UseVisualStyleBackColor = true;
            // 
            // tabPage20
            // 
            this.tabPage20.Controls.Add(this.button20);
            this.tabPage20.Controls.Add(this.label22);
            this.tabPage20.Controls.Add(this.radioButton59);
            this.tabPage20.Controls.Add(this.radioButton60);
            this.tabPage20.Controls.Add(this.radioButton61);
            this.tabPage20.Location = new System.Drawing.Point(4, 29);
            this.tabPage20.Name = "tabPage20";
            this.tabPage20.Size = new System.Drawing.Size(522, 572);
            this.tabPage20.TabIndex = 19;
            this.tabPage20.Text = "19";
            this.tabPage20.UseVisualStyleBackColor = true;
            // 
            // tabPage21
            // 
            this.tabPage21.Controls.Add(this.button21);
            this.tabPage21.Controls.Add(this.label23);
            this.tabPage21.Controls.Add(this.radioButton62);
            this.tabPage21.Controls.Add(this.radioButton63);
            this.tabPage21.Controls.Add(this.radioButton64);
            this.tabPage21.Location = new System.Drawing.Point(4, 29);
            this.tabPage21.Name = "tabPage21";
            this.tabPage21.Size = new System.Drawing.Size(522, 572);
            this.tabPage21.TabIndex = 20;
            this.tabPage21.Text = "20";
            this.tabPage21.UseVisualStyleBackColor = true;
            // 
            // tabPage22
            // 
            this.tabPage22.Controls.Add(this.button22);
            this.tabPage22.Controls.Add(this.label24);
            this.tabPage22.Controls.Add(this.radioButton65);
            this.tabPage22.Controls.Add(this.radioButton66);
            this.tabPage22.Controls.Add(this.radioButton67);
            this.tabPage22.Location = new System.Drawing.Point(4, 29);
            this.tabPage22.Name = "tabPage22";
            this.tabPage22.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tabPage22.Size = new System.Drawing.Size(522, 572);
            this.tabPage22.TabIndex = 21;
            this.tabPage22.Text = "21";
            this.tabPage22.UseVisualStyleBackColor = true;
            // 
            // tabPage23
            // 
            this.tabPage23.Controls.Add(this.button23);
            this.tabPage23.Controls.Add(this.label25);
            this.tabPage23.Controls.Add(this.radioButton68);
            this.tabPage23.Controls.Add(this.radioButton69);
            this.tabPage23.Controls.Add(this.radioButton70);
            this.tabPage23.Location = new System.Drawing.Point(4, 29);
            this.tabPage23.Name = "tabPage23";
            this.tabPage23.Size = new System.Drawing.Size(522, 572);
            this.tabPage23.TabIndex = 22;
            this.tabPage23.Text = "22";
            this.tabPage23.UseVisualStyleBackColor = true;
            // 
            // tabPage24
            // 
            this.tabPage24.Controls.Add(this.button24);
            this.tabPage24.Controls.Add(this.label26);
            this.tabPage24.Controls.Add(this.radioButton71);
            this.tabPage24.Controls.Add(this.radioButton72);
            this.tabPage24.Controls.Add(this.radioButton73);
            this.tabPage24.Location = new System.Drawing.Point(4, 29);
            this.tabPage24.Name = "tabPage24";
            this.tabPage24.Size = new System.Drawing.Size(522, 572);
            this.tabPage24.TabIndex = 23;
            this.tabPage24.Text = "23";
            this.tabPage24.UseVisualStyleBackColor = true;
            // 
            // tabPage25
            // 
            this.tabPage25.Controls.Add(this.textBox1);
            this.tabPage25.Controls.Add(this.button25);
            this.tabPage25.Controls.Add(this.label27);
            this.tabPage25.Location = new System.Drawing.Point(4, 29);
            this.tabPage25.Name = "tabPage25";
            this.tabPage25.Size = new System.Drawing.Size(522, 572);
            this.tabPage25.TabIndex = 24;
            this.tabPage25.Text = "24";
            this.tabPage25.UseVisualStyleBackColor = true;
            // 
            // tabPage26
            // 
            this.tabPage26.Controls.Add(this.button26);
            this.tabPage26.Controls.Add(this.label28);
            this.tabPage26.Controls.Add(this.radioButton74);
            this.tabPage26.Controls.Add(this.radioButton75);
            this.tabPage26.Controls.Add(this.radioButton76);
            this.tabPage26.Location = new System.Drawing.Point(4, 29);
            this.tabPage26.Name = "tabPage26";
            this.tabPage26.Size = new System.Drawing.Size(522, 572);
            this.tabPage26.TabIndex = 25;
            this.tabPage26.Text = "25";
            this.tabPage26.UseVisualStyleBackColor = true;
            // 
            // tabPage27
            // 
            this.tabPage27.Controls.Add(this.textBox2);
            this.tabPage27.Controls.Add(this.button27);
            this.tabPage27.Controls.Add(this.label29);
            this.tabPage27.Location = new System.Drawing.Point(4, 29);
            this.tabPage27.Name = "tabPage27";
            this.tabPage27.Size = new System.Drawing.Size(522, 572);
            this.tabPage27.TabIndex = 26;
            this.tabPage27.Text = "26";
            this.tabPage27.UseVisualStyleBackColor = true;
            // 
            // tabPage28
            // 
            this.tabPage28.Controls.Add(this.button28);
            this.tabPage28.Controls.Add(this.label30);
            this.tabPage28.Controls.Add(this.radioButton77);
            this.tabPage28.Controls.Add(this.radioButton78);
            this.tabPage28.Controls.Add(this.radioButton79);
            this.tabPage28.Location = new System.Drawing.Point(4, 29);
            this.tabPage28.Name = "tabPage28";
            this.tabPage28.Size = new System.Drawing.Size(522, 572);
            this.tabPage28.TabIndex = 27;
            this.tabPage28.Text = "27";
            this.tabPage28.UseVisualStyleBackColor = true;
            // 
            // tabPage29
            // 
            this.tabPage29.Controls.Add(this.button29);
            this.tabPage29.Controls.Add(this.label31);
            this.tabPage29.Controls.Add(this.radioButton80);
            this.tabPage29.Controls.Add(this.radioButton81);
            this.tabPage29.Controls.Add(this.radioButton82);
            this.tabPage29.Location = new System.Drawing.Point(4, 29);
            this.tabPage29.Name = "tabPage29";
            this.tabPage29.Size = new System.Drawing.Size(522, 572);
            this.tabPage29.TabIndex = 28;
            this.tabPage29.Text = "28";
            this.tabPage29.UseVisualStyleBackColor = true;
            // 
            // tabPage30
            // 
            this.tabPage30.Controls.Add(this.button30);
            this.tabPage30.Controls.Add(this.label32);
            this.tabPage30.Controls.Add(this.radioButton83);
            this.tabPage30.Controls.Add(this.radioButton84);
            this.tabPage30.Controls.Add(this.radioButton85);
            this.tabPage30.Location = new System.Drawing.Point(4, 29);
            this.tabPage30.Name = "tabPage30";
            this.tabPage30.Size = new System.Drawing.Size(522, 572);
            this.tabPage30.TabIndex = 29;
            this.tabPage30.Text = "29";
            this.tabPage30.UseVisualStyleBackColor = true;
            // 
            // tabPage31
            // 
            this.tabPage31.Controls.Add(this.button31);
            this.tabPage31.Controls.Add(this.label33);
            this.tabPage31.Controls.Add(this.radioButton86);
            this.tabPage31.Controls.Add(this.radioButton87);
            this.tabPage31.Controls.Add(this.radioButton88);
            this.tabPage31.Location = new System.Drawing.Point(4, 29);
            this.tabPage31.Name = "tabPage31";
            this.tabPage31.Size = new System.Drawing.Size(522, 572);
            this.tabPage31.TabIndex = 30;
            this.tabPage31.Text = "30";
            this.tabPage31.UseVisualStyleBackColor = true;
            // 
            // tabPage32
            // 
            this.tabPage32.Controls.Add(this.button33);
            this.tabPage32.Controls.Add(this.button32);
            this.tabPage32.Controls.Add(this.label35);
            this.tabPage32.Controls.Add(this.label34);
            this.tabPage32.Location = new System.Drawing.Point(4, 29);
            this.tabPage32.Name = "tabPage32";
            this.tabPage32.Size = new System.Drawing.Size(522, 572);
            this.tabPage32.TabIndex = 31;
            this.tabPage32.Text = "Оценка";
            this.tabPage32.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(356, 466);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(140, 38);
            this.button3.TabIndex = 11;
            this.button3.Text = "Далее";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(57, 112);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(282, 40);
            this.label3.TabIndex = 10;
            this.label3.Text = "Какой из следующих вариантов \r\nобъявления массива в C# неверен?";
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.Location = new System.Drawing.Point(61, 263);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(295, 24);
            this.radioButton5.TabIndex = 9;
            this.radioButton5.TabStop = true;
            this.radioButton5.Text = "int[] numbers = new int[] {1, 2, 3, 4, 5};";
            this.radioButton5.UseVisualStyleBackColor = true;
            // 
            // radioButton6
            // 
            this.radioButton6.AutoSize = true;
            this.radioButton6.Location = new System.Drawing.Point(61, 233);
            this.radioButton6.Name = "radioButton6";
            this.radioButton6.Size = new System.Drawing.Size(233, 24);
            this.radioButton6.TabIndex = 8;
            this.radioButton6.TabStop = true;
            this.radioButton6.Text = "int[] numbers = {1, 2, 3, 4, 5};";
            this.radioButton6.UseVisualStyleBackColor = true;
            // 
            // radioButton7
            // 
            this.radioButton7.AutoSize = true;
            this.radioButton7.Location = new System.Drawing.Point(61, 203);
            this.radioButton7.Name = "radioButton7";
            this.radioButton7.Size = new System.Drawing.Size(222, 24);
            this.radioButton7.TabIndex = 7;
            this.radioButton7.TabStop = true;
            this.radioButton7.Text = "int numbers[5] = new int[5];";
            this.radioButton7.UseVisualStyleBackColor = true;
            // 
            // radioButton8
            // 
            this.radioButton8.AutoSize = true;
            this.radioButton8.Location = new System.Drawing.Point(61, 173);
            this.radioButton8.Name = "radioButton8";
            this.radioButton8.Size = new System.Drawing.Size(209, 24);
            this.radioButton8.TabIndex = 6;
            this.radioButton8.TabStop = true;
            this.radioButton8.Text = "int[] numbers = new int[5]";
            this.radioButton8.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(341, 444);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(140, 38);
            this.button4.TabIndex = 17;
            this.button4.Text = "Далее";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(42, 91);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(181, 40);
            this.label4.TabIndex = 16;
            this.label4.Text = "Каким образом можно \r\nобъявить константу?\r\n";
            // 
            // radioButton10
            // 
            this.radioButton10.AutoSize = true;
            this.radioButton10.Location = new System.Drawing.Point(46, 211);
            this.radioButton10.Name = "radioButton10";
            this.radioButton10.Size = new System.Drawing.Size(243, 24);
            this.radioButton10.TabIndex = 14;
            this.radioButton10.TabStop = true;
            this.radioButton10.Text = "static int MAX_VALUE = 100;";
            this.radioButton10.UseVisualStyleBackColor = true;
            // 
            // radioButton11
            // 
            this.radioButton11.AutoSize = true;
            this.radioButton11.Location = new System.Drawing.Point(46, 181);
            this.radioButton11.Name = "radioButton11";
            this.radioButton11.Size = new System.Drawing.Size(265, 24);
            this.radioButton11.TabIndex = 13;
            this.radioButton11.TabStop = true;
            this.radioButton11.Text = "readonly int MAX_VALUE = 100;";
            this.radioButton11.UseVisualStyleBackColor = true;
            // 
            // radioButton12
            // 
            this.radioButton12.AutoSize = true;
            this.radioButton12.Location = new System.Drawing.Point(46, 151);
            this.radioButton12.Name = "radioButton12";
            this.radioButton12.Size = new System.Drawing.Size(244, 24);
            this.radioButton12.TabIndex = 12;
            this.radioButton12.TabStop = true;
            this.radioButton12.Text = "const int MAX_VALUE = 100;";
            this.radioButton12.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(341, 444);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(140, 38);
            this.button5.TabIndex = 22;
            this.button5.Text = "Далее";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(42, 92);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(263, 40);
            this.label5.TabIndex = 21;
            this.label5.Text = "Какой из следующих операторов \r\nприведения типов неверен?\r\n";
            // 
            // radioButton9
            // 
            this.radioButton9.AutoSize = true;
            this.radioButton9.Location = new System.Drawing.Point(46, 211);
            this.radioButton9.Name = "radioButton9";
            this.radioButton9.Size = new System.Drawing.Size(80, 24);
            this.radioButton9.TabIndex = 20;
            this.radioButton9.TabStop = true;
            this.radioButton9.Text = "(int[])x;";
            this.radioButton9.UseVisualStyleBackColor = true;
            // 
            // radioButton13
            // 
            this.radioButton13.AutoSize = true;
            this.radioButton13.Location = new System.Drawing.Point(46, 181);
            this.radioButton13.Name = "radioButton13";
            this.radioButton13.Size = new System.Drawing.Size(94, 24);
            this.radioButton13.TabIndex = 19;
            this.radioButton13.TabStop = true;
            this.radioButton13.Text = "(string)x;";
            this.radioButton13.UseVisualStyleBackColor = true;
            // 
            // radioButton14
            // 
            this.radioButton14.AutoSize = true;
            this.radioButton14.Location = new System.Drawing.Point(46, 151);
            this.radioButton14.Name = "radioButton14";
            this.radioButton14.Size = new System.Drawing.Size(72, 24);
            this.radioButton14.TabIndex = 18;
            this.radioButton14.TabStop = true;
            this.radioButton14.Text = "(int)x;";
            this.radioButton14.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(341, 443);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(140, 38);
            this.button6.TabIndex = 27;
            this.button6.Text = "Далее";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(42, 92);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(254, 40);
            this.label6.TabIndex = 26;
            this.label6.Text = "Какой из следующих вариантов \r\nцикла является неверным?\r\n";
            // 
            // radioButton15
            // 
            this.radioButton15.AutoSize = true;
            this.radioButton15.Location = new System.Drawing.Point(46, 210);
            this.radioButton15.Name = "radioButton15";
            this.radioButton15.Size = new System.Drawing.Size(226, 24);
            this.radioButton15.TabIndex = 25;
            this.radioButton15.TabStop = true;
            this.radioButton15.Text = "while (int i = 0; i < 10; i++) { }";
            this.radioButton15.UseVisualStyleBackColor = true;
            // 
            // radioButton16
            // 
            this.radioButton16.AutoSize = true;
            this.radioButton16.Location = new System.Drawing.Point(46, 180);
            this.radioButton16.Name = "radioButton16";
            this.radioButton16.Size = new System.Drawing.Size(236, 24);
            this.radioButton16.TabIndex = 24;
            this.radioButton16.TabStop = true;
            this.radioButton16.Text = "foreach (int num in numbers)";
            this.radioButton16.UseVisualStyleBackColor = true;
            // 
            // radioButton17
            // 
            this.radioButton17.AutoSize = true;
            this.radioButton17.Location = new System.Drawing.Point(46, 150);
            this.radioButton17.Name = "radioButton17";
            this.radioButton17.Size = new System.Drawing.Size(192, 24);
            this.radioButton17.TabIndex = 23;
            this.radioButton17.TabStop = true;
            this.radioButton17.Text = "for (int i = 0; i < 10; i++)";
            this.radioButton17.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(341, 443);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(140, 38);
            this.button7.TabIndex = 32;
            this.button7.Text = "Далее";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.Location = new System.Drawing.Point(42, 92);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(243, 40);
            this.label7.TabIndex = 31;
            this.label7.Text = "Как объявить метод, который \r\nне возвращает значение?";
            // 
            // radioButton18
            // 
            this.radioButton18.AutoSize = true;
            this.radioButton18.Location = new System.Drawing.Point(46, 210);
            this.radioButton18.Name = "radioButton18";
            this.radioButton18.Size = new System.Drawing.Size(186, 24);
            this.radioButton18.TabIndex = 30;
            this.radioButton18.TabStop = true;
            this.radioButton18.Text = "void methodName() {}";
            this.radioButton18.UseVisualStyleBackColor = true;
            // 
            // radioButton19
            // 
            this.radioButton19.AutoSize = true;
            this.radioButton19.Location = new System.Drawing.Point(46, 180);
            this.radioButton19.Name = "radioButton19";
            this.radioButton19.Size = new System.Drawing.Size(154, 24);
            this.radioButton19.TabIndex = 29;
            this.radioButton19.TabStop = true;
            this.radioButton19.Text = "methodName() {}";
            this.radioButton19.UseVisualStyleBackColor = true;
            // 
            // radioButton20
            // 
            this.radioButton20.AutoSize = true;
            this.radioButton20.Location = new System.Drawing.Point(46, 150);
            this.radioButton20.Name = "radioButton20";
            this.radioButton20.Size = new System.Drawing.Size(175, 24);
            this.radioButton20.TabIndex = 28;
            this.radioButton20.TabStop = true;
            this.radioButton20.Text = "int methodName() {}\r\n";
            this.radioButton20.UseVisualStyleBackColor = true;
            // 
            // radioButton21
            // 
            this.radioButton21.AutoSize = true;
            this.radioButton21.Location = new System.Drawing.Point(46, 240);
            this.radioButton21.Name = "radioButton21";
            this.radioButton21.Size = new System.Drawing.Size(155, 24);
            this.radioButton21.TabIndex = 33;
            this.radioButton21.TabStop = true;
            this.radioButton21.Text = "int methodName;";
            this.radioButton21.UseVisualStyleBackColor = true;
            // 
            // radioButton22
            // 
            this.radioButton22.AutoSize = true;
            this.radioButton22.Location = new System.Drawing.Point(46, 240);
            this.radioButton22.Name = "radioButton22";
            this.radioButton22.Size = new System.Drawing.Size(217, 24);
            this.radioButton22.TabIndex = 39;
            this.radioButton22.TabStop = true;
            this.radioButton22.Text = "string str = \"Hello, World!\";";
            this.radioButton22.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(341, 443);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(140, 38);
            this.button8.TabIndex = 38;
            this.button8.Text = "Далее";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.Location = new System.Drawing.Point(42, 93);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(377, 40);
            this.label8.TabIndex = 37;
            this.label8.Text = "Какие из следующих вариантов представления \r\nстроки в C# являются правильными?";
            // 
            // radioButton23
            // 
            this.radioButton23.AutoSize = true;
            this.radioButton23.Location = new System.Drawing.Point(46, 210);
            this.radioButton23.Name = "radioButton23";
            this.radioButton23.Size = new System.Drawing.Size(151, 24);
            this.radioButton23.TabIndex = 36;
            this.radioButton23.TabStop = true;
            this.radioButton23.Text = "@\"Hello, World!\"";
            this.radioButton23.UseVisualStyleBackColor = true;
            // 
            // radioButton24
            // 
            this.radioButton24.AutoSize = true;
            this.radioButton24.Location = new System.Drawing.Point(46, 180);
            this.radioButton24.Name = "radioButton24";
            this.radioButton24.Size = new System.Drawing.Size(129, 24);
            this.radioButton24.TabIndex = 35;
            this.radioButton24.TabStop = true;
            this.radioButton24.Text = "\'Hello, World!\'";
            this.radioButton24.UseVisualStyleBackColor = true;
            // 
            // radioButton25
            // 
            this.radioButton25.AutoSize = true;
            this.radioButton25.Location = new System.Drawing.Point(46, 150);
            this.radioButton25.Name = "radioButton25";
            this.radioButton25.Size = new System.Drawing.Size(135, 24);
            this.radioButton25.TabIndex = 34;
            this.radioButton25.TabStop = true;
            this.radioButton25.Text = "\"Hello, World!\"";
            this.radioButton25.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(341, 442);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(140, 38);
            this.button9.TabIndex = 44;
            this.button9.Text = "Далее";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.Location = new System.Drawing.Point(43, 93);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(279, 40);
            this.label9.TabIndex = 43;
            this.label9.Text = "Как объявить и инициализировать \r\nпеременную в одной строке в C#?";
            // 
            // radioButton27
            // 
            this.radioButton27.AutoSize = true;
            this.radioButton27.Location = new System.Drawing.Point(46, 209);
            this.radioButton27.Name = "radioButton27";
            this.radioButton27.Size = new System.Drawing.Size(117, 24);
            this.radioButton27.TabIndex = 42;
            this.radioButton27.TabStop = true;
            this.radioButton27.Text = "int x; int = 5;";
            this.radioButton27.UseVisualStyleBackColor = true;
            // 
            // radioButton28
            // 
            this.radioButton28.AutoSize = true;
            this.radioButton28.Location = new System.Drawing.Point(46, 179);
            this.radioButton28.Name = "radioButton28";
            this.radioButton28.Size = new System.Drawing.Size(107, 24);
            this.radioButton28.TabIndex = 41;
            this.radioButton28.TabStop = true;
            this.radioButton28.Text = "int x; x = 5;";
            this.radioButton28.UseVisualStyleBackColor = true;
            // 
            // radioButton29
            // 
            this.radioButton29.AutoSize = true;
            this.radioButton29.Location = new System.Drawing.Point(46, 149);
            this.radioButton29.Name = "radioButton29";
            this.radioButton29.Size = new System.Drawing.Size(92, 24);
            this.radioButton29.TabIndex = 40;
            this.radioButton29.TabStop = true;
            this.radioButton29.Text = "int x = 5;";
            this.radioButton29.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(340, 442);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(140, 38);
            this.button10.TabIndex = 49;
            this.button10.Text = "Далее";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.Location = new System.Drawing.Point(42, 94);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(244, 40);
            this.label10.TabIndex = 48;
            this.label10.Text = "Какой оператор используется \r\nдля сравнения значений в C#?";
            // 
            // radioButton26
            // 
            this.radioButton26.AutoSize = true;
            this.radioButton26.Location = new System.Drawing.Point(45, 209);
            this.radioButton26.Name = "radioButton26";
            this.radioButton26.Size = new System.Drawing.Size(52, 24);
            this.radioButton26.TabIndex = 47;
            this.radioButton26.TabStop = true;
            this.radioButton26.Text = "><";
            this.radioButton26.UseVisualStyleBackColor = true;
            // 
            // radioButton30
            // 
            this.radioButton30.AutoSize = true;
            this.radioButton30.Location = new System.Drawing.Point(45, 179);
            this.radioButton30.Name = "radioButton30";
            this.radioButton30.Size = new System.Drawing.Size(43, 24);
            this.radioButton30.TabIndex = 46;
            this.radioButton30.TabStop = true;
            this.radioButton30.Text = "=";
            this.radioButton30.UseVisualStyleBackColor = true;
            // 
            // radioButton31
            // 
            this.radioButton31.AutoSize = true;
            this.radioButton31.Location = new System.Drawing.Point(45, 149);
            this.radioButton31.Name = "radioButton31";
            this.radioButton31.Size = new System.Drawing.Size(52, 24);
            this.radioButton31.TabIndex = 45;
            this.radioButton31.TabStop = true;
            this.radioButton31.Text = "==";
            this.radioButton31.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(340, 441);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(140, 38);
            this.button11.TabIndex = 54;
            this.button11.Text = "Далее";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label11.Location = new System.Drawing.Point(42, 94);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(295, 40);
            this.label11.TabIndex = 53;
            this.label11.Text = "Как объявить переменную, которая \r\nможет содержать значение null в C#?";
            // 
            // radioButton32
            // 
            this.radioButton32.AutoSize = true;
            this.radioButton32.Location = new System.Drawing.Point(45, 208);
            this.radioButton32.Name = "radioButton32";
            this.radioButton32.Size = new System.Drawing.Size(116, 24);
            this.radioButton32.TabIndex = 52;
            this.radioButton32.TabStop = true;
            this.radioButton32.Text = "int? x = null;";
            this.radioButton32.UseVisualStyleBackColor = true;
            // 
            // radioButton33
            // 
            this.radioButton33.AutoSize = true;
            this.radioButton33.Location = new System.Drawing.Point(45, 178);
            this.radioButton33.Name = "radioButton33";
            this.radioButton33.Size = new System.Drawing.Size(75, 24);
            this.radioButton33.TabIndex = 51;
            this.radioButton33.TabStop = true;
            this.radioButton33.Text = "int? x;";
            this.radioButton33.UseVisualStyleBackColor = true;
            // 
            // radioButton34
            // 
            this.radioButton34.AutoSize = true;
            this.radioButton34.Location = new System.Drawing.Point(45, 148);
            this.radioButton34.Name = "radioButton34";
            this.radioButton34.Size = new System.Drawing.Size(107, 24);
            this.radioButton34.TabIndex = 50;
            this.radioButton34.TabStop = true;
            this.radioButton34.Text = "int x = null;";
            this.radioButton34.UseVisualStyleBackColor = true;
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(340, 441);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(140, 38);
            this.button12.TabIndex = 59;
            this.button12.Text = "Далее";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label12.Location = new System.Drawing.Point(42, 95);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(316, 40);
            this.label12.TabIndex = 58;
            this.label12.Text = "Какой из следующих вариантов\r\nправильно преобразует строку в число?\r\n";
            // 
            // radioButton35
            // 
            this.radioButton35.AutoSize = true;
            this.radioButton35.Location = new System.Drawing.Point(45, 178);
            this.radioButton35.Name = "radioButton35";
            this.radioButton35.Size = new System.Drawing.Size(192, 24);
            this.radioButton35.TabIndex = 57;
            this.radioButton35.TabStop = true;
            this.radioButton35.Text = "Convert.ToInt32(\"10\");";
            this.radioButton35.UseVisualStyleBackColor = true;
            // 
            // radioButton36
            // 
            this.radioButton36.AutoSize = true;
            this.radioButton36.Location = new System.Drawing.Point(45, 208);
            this.radioButton36.Name = "radioButton36";
            this.radioButton36.Size = new System.Drawing.Size(125, 24);
            this.radioButton36.TabIndex = 56;
            this.radioButton36.TabStop = true;
            this.radioButton36.Text = "Both a and b";
            this.radioButton36.UseVisualStyleBackColor = true;
            // 
            // radioButton37
            // 
            this.radioButton37.AutoSize = true;
            this.radioButton37.Location = new System.Drawing.Point(45, 148);
            this.radioButton37.Name = "radioButton37";
            this.radioButton37.Size = new System.Drawing.Size(140, 24);
            this.radioButton37.TabIndex = 55;
            this.radioButton37.TabStop = true;
            this.radioButton37.Text = "int.Parse(\"10\");";
            this.radioButton37.UseVisualStyleBackColor = true;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label13.Location = new System.Drawing.Point(42, 270);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(320, 40);
            this.label13.TabIndex = 60;
            this.label13.Text = "*верный ответ, в случае невозможности \r\n  преобразования, бросает исключения";
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(340, 440);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(140, 38);
            this.button13.TabIndex = 65;
            this.button13.Text = "Далее";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label15.Location = new System.Drawing.Point(42, 95);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(303, 40);
            this.label15.TabIndex = 64;
            this.label15.Text = "Какой оператор используется для \r\nвыделения памяти для объекта в C#?";
            // 
            // radioButton38
            // 
            this.radioButton38.AutoSize = true;
            this.radioButton38.Location = new System.Drawing.Point(45, 177);
            this.radioButton38.Name = "radioButton38";
            this.radioButton38.Size = new System.Drawing.Size(79, 24);
            this.radioButton38.TabIndex = 63;
            this.radioButton38.TabStop = true;
            this.radioButton38.Text = "malloc";
            this.radioButton38.UseVisualStyleBackColor = true;
            // 
            // radioButton39
            // 
            this.radioButton39.AutoSize = true;
            this.radioButton39.Location = new System.Drawing.Point(45, 207);
            this.radioButton39.Name = "radioButton39";
            this.radioButton39.Size = new System.Drawing.Size(63, 24);
            this.radioButton39.TabIndex = 62;
            this.radioButton39.TabStop = true;
            this.radioButton39.Text = "new";
            this.radioButton39.UseVisualStyleBackColor = true;
            // 
            // radioButton40
            // 
            this.radioButton40.AutoSize = true;
            this.radioButton40.Location = new System.Drawing.Point(45, 147);
            this.radioButton40.Name = "radioButton40";
            this.radioButton40.Size = new System.Drawing.Size(66, 24);
            this.radioButton40.TabIndex = 61;
            this.radioButton40.TabStop = true;
            this.radioButton40.Text = "alloc";
            this.radioButton40.UseVisualStyleBackColor = true;
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(340, 440);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(140, 38);
            this.button14.TabIndex = 70;
            this.button14.Text = "Далее";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label14.Location = new System.Drawing.Point(43, 96);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(377, 20);
            this.label14.TabIndex = 69;
            this.label14.Text = "Как правильно создать экземпляр класса в C#?";
            // 
            // radioButton41
            // 
            this.radioButton41.AutoSize = true;
            this.radioButton41.Location = new System.Drawing.Point(45, 147);
            this.radioButton41.Name = "radioButton41";
            this.radioButton41.Size = new System.Drawing.Size(140, 24);
            this.radioButton41.TabIndex = 68;
            this.radioButton41.TabStop = true;
            this.radioButton41.Text = "new MyClass();";
            this.radioButton41.UseVisualStyleBackColor = true;
            // 
            // radioButton42
            // 
            this.radioButton42.AutoSize = true;
            this.radioButton42.Location = new System.Drawing.Point(45, 207);
            this.radioButton42.Name = "radioButton42";
            this.radioButton42.Size = new System.Drawing.Size(156, 24);
            this.radioButton42.TabIndex = 67;
            this.radioButton42.TabStop = true;
            this.radioButton42.Text = "create MyClass();";
            this.radioButton42.UseVisualStyleBackColor = true;
            // 
            // radioButton43
            // 
            this.radioButton43.AutoSize = true;
            this.radioButton43.Location = new System.Drawing.Point(45, 177);
            this.radioButton43.Name = "radioButton43";
            this.radioButton43.Size = new System.Drawing.Size(107, 24);
            this.radioButton43.TabIndex = 66;
            this.radioButton43.TabStop = true;
            this.radioButton43.Text = "MyClass();";
            this.radioButton43.UseVisualStyleBackColor = true;
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(340, 439);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(140, 38);
            this.button15.TabIndex = 75;
            this.button15.Text = "Далее";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label16.Location = new System.Drawing.Point(43, 96);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(484, 40);
            this.label16.TabIndex = 74;
            this.label16.Text = "Какое ключевое слово используется для определения \r\nметода, который переопределяе" +
    "т метод из базового класса?\r\n";
            // 
            // radioButton44
            // 
            this.radioButton44.AutoSize = true;
            this.radioButton44.Location = new System.Drawing.Point(45, 146);
            this.radioButton44.Name = "radioButton44";
            this.radioButton44.Size = new System.Drawing.Size(90, 24);
            this.radioButton44.TabIndex = 73;
            this.radioButton44.TabStop = true;
            this.radioButton44.Text = "override";
            this.radioButton44.UseVisualStyleBackColor = true;
            // 
            // radioButton45
            // 
            this.radioButton45.AutoSize = true;
            this.radioButton45.Location = new System.Drawing.Point(45, 206);
            this.radioButton45.Name = "radioButton45";
            this.radioButton45.Size = new System.Drawing.Size(75, 24);
            this.radioButton45.TabIndex = 72;
            this.radioButton45.TabStop = true;
            this.radioButton45.Text = "virtual";
            this.radioButton45.UseVisualStyleBackColor = true;
            // 
            // radioButton46
            // 
            this.radioButton46.AutoSize = true;
            this.radioButton46.Location = new System.Drawing.Point(45, 176);
            this.radioButton46.Name = "radioButton46";
            this.radioButton46.Size = new System.Drawing.Size(69, 24);
            this.radioButton46.TabIndex = 71;
            this.radioButton46.TabStop = true;
            this.radioButton46.Text = "base";
            this.radioButton46.UseVisualStyleBackColor = true;
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(340, 439);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(140, 38);
            this.button16.TabIndex = 75;
            this.button16.Text = "Далее";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label17.Location = new System.Drawing.Point(44, 96);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(281, 40);
            this.label17.TabIndex = 74;
            this.label17.Text = "Какой из следующих операторов \r\nиспользуется для логического \"И\"?";
            // 
            // radioButton47
            // 
            this.radioButton47.AutoSize = true;
            this.radioButton47.Location = new System.Drawing.Point(45, 146);
            this.radioButton47.Name = "radioButton47";
            this.radioButton47.Size = new System.Drawing.Size(44, 24);
            this.radioButton47.TabIndex = 73;
            this.radioButton47.TabStop = true;
            this.radioButton47.Text = "||";
            this.radioButton47.UseVisualStyleBackColor = true;
            // 
            // radioButton48
            // 
            this.radioButton48.AutoSize = true;
            this.radioButton48.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.radioButton48.Location = new System.Drawing.Point(45, 206);
            this.radioButton48.Name = "radioButton48";
            this.radioButton48.Size = new System.Drawing.Size(45, 24);
            this.radioButton48.TabIndex = 72;
            this.radioButton48.TabStop = true;
            this.radioButton48.Text = "&&\r\n";
            this.radioButton48.UseVisualStyleBackColor = true;
            // radioButton49
            // 
            this.radioButton49.AutoSize = true;
            this.radioButton49.Location = new System.Drawing.Point(45, 176);
            this.radioButton49.Name = "radioButton49";
            this.radioButton49.Size = new System.Drawing.Size(62, 24);
            this.radioButton49.TabIndex = 71;
            this.radioButton49.TabStop = true;
            this.radioButton49.Text = "%%";
            this.radioButton49.UseVisualStyleBackColor = true;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(87, 208);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(20, 20);
            this.label18.TabIndex = 76;
            this.label18.Text = "&&";
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(340, 439);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(140, 38);
            this.button17.TabIndex = 75;
            this.button17.Text = "Далее";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label19.Location = new System.Drawing.Point(44, 96);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(359, 20);
            this.label19.TabIndex = 74;
            this.label19.Text = "Как правильно объявить пустой массив в C#?";
            // 
            // radioButton50
            // 
            this.radioButton50.AutoSize = true;
            this.radioButton50.Location = new System.Drawing.Point(45, 146);
            this.radioButton50.Name = "radioButton50";
            this.radioButton50.Size = new System.Drawing.Size(213, 24);
            this.radioButton50.TabIndex = 73;
            this.radioButton50.TabStop = true;
            this.radioButton50.Text = "int[] numbers = new int[0];";
            this.radioButton50.UseVisualStyleBackColor = true;
            // 
            // radioButton51
            // 
            this.radioButton51.AutoSize = true;
            this.radioButton51.Location = new System.Drawing.Point(45, 206);
            this.radioButton51.Name = "radioButton51";
            this.radioButton51.Size = new System.Drawing.Size(204, 24);
            this.radioButton51.TabIndex = 72;
            this.radioButton51.TabStop = true;
            this.radioButton51.Text = "int numbers[] = new int[];";
            this.radioButton51.UseVisualStyleBackColor = true;
            // 
            // radioButton52
            // 
            this.radioButton52.AutoSize = true;
            this.radioButton52.Location = new System.Drawing.Point(45, 176);
            this.radioButton52.Name = "radioButton52";
            this.radioButton52.Size = new System.Drawing.Size(156, 24);
            this.radioButton52.TabIndex = 71;
            this.radioButton52.TabStop = true;
            this.radioButton52.Text = "int[] numbers = {};";
            this.radioButton52.UseVisualStyleBackColor = true;
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(339, 439);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(140, 38);
            this.button18.TabIndex = 80;
            this.button18.Text = "Далее";
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label20.Location = new System.Drawing.Point(44, 97);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(332, 40);
            this.label20.TabIndex = 79;
            this.label20.Text = "Как объявить метод, который принимает \r\nпеременное количество аргументов в C#?";
            // 
            // radioButton53
            // 
            this.radioButton53.AutoSize = true;
            this.radioButton53.Location = new System.Drawing.Point(44, 146);
            this.radioButton53.Name = "radioButton53";
            this.radioButton53.Size = new System.Drawing.Size(338, 24);
            this.radioButton53.TabIndex = 78;
            this.radioButton53.TabStop = true;
            this.radioButton53.Text = "void MethodName(params int[] numbers) { }";
            this.radioButton53.UseVisualStyleBackColor = true;
            // 
            // radioButton54
            // 
            this.radioButton54.AutoSize = true;
            this.radioButton54.Location = new System.Drawing.Point(44, 206);
            this.radioButton54.Name = "radioButton54";
            this.radioButton54.Size = new System.Drawing.Size(281, 24);
            this.radioButton54.TabIndex = 77;
            this.radioButton54.TabStop = true;
            this.radioButton54.Text = "void MethodName(int numbers[]) { }";
            this.radioButton54.UseVisualStyleBackColor = true;
            // 
            // radioButton55
            // 
            this.radioButton55.AutoSize = true;
            this.radioButton55.Location = new System.Drawing.Point(44, 176);
            this.radioButton55.Name = "radioButton55";
            this.radioButton55.Size = new System.Drawing.Size(281, 24);
            this.radioButton55.TabIndex = 76;
            this.radioButton55.TabStop = true;
            this.radioButton55.Text = "void MethodName(int[] numbers) { }";
            this.radioButton55.UseVisualStyleBackColor = true;
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(339, 438);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(140, 38);
            this.button19.TabIndex = 85;
            this.button19.Text = "Далее";
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label21.Location = new System.Drawing.Point(44, 97);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(340, 40);
            this.label21.TabIndex = 84;
            this.label21.Text = "Какие из следующих вариантов правильно \r\nиспользуют ключевое слово \"this\" в C#?";
            // 
            // radioButton56
            // 
            this.radioButton56.AutoSize = true;
            this.radioButton56.Location = new System.Drawing.Point(44, 145);
            this.radioButton56.Name = "radioButton56";
            this.radioButton56.Size = new System.Drawing.Size(109, 24);
            this.radioButton56.TabIndex = 83;
            this.radioButton56.TabStop = true;
            this.radioButton56.Text = "this.x = 10;";
            this.radioButton56.UseVisualStyleBackColor = true;
            // 
            // radioButton57
            // 
            this.radioButton57.AutoSize = true;
            this.radioButton57.Location = new System.Drawing.Point(44, 205);
            this.radioButton57.Name = "radioButton57";
            this.radioButton57.Size = new System.Drawing.Size(236, 24);
            this.radioButton57.TabIndex = 82;
            this.radioButton57.TabStop = true;
            this.radioButton57.Text = "MyClass.this.MethodName();";
            this.radioButton57.UseVisualStyleBackColor = true;
            // 
            // radioButton58
            // 
            this.radioButton58.AutoSize = true;
            this.radioButton58.Location = new System.Drawing.Point(44, 175);
            this.radioButton58.Name = "radioButton58";
            this.radioButton58.Size = new System.Drawing.Size(173, 24);
            this.radioButton58.TabIndex = 81;
            this.radioButton58.TabStop = true;
            this.radioButton58.Text = "this.MethodName();";
            this.radioButton58.UseVisualStyleBackColor = true;
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(339, 438);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(140, 38);
            this.button20.TabIndex = 90;
            this.button20.Text = "Далее";
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label22.Location = new System.Drawing.Point(44, 97);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(257, 40);
            this.label22.TabIndex = 89;
            this.label22.Text = "Какой тип данных используется \r\nдля хранения символов в C#?";
            // 
            // radioButton59
            // 
            this.radioButton59.AutoSize = true;
            this.radioButton59.Location = new System.Drawing.Point(44, 145);
            this.radioButton59.Name = "radioButton59";
            this.radioButton59.Size = new System.Drawing.Size(65, 24);
            this.radioButton59.TabIndex = 88;
            this.radioButton59.TabStop = true;
            this.radioButton59.Text = "char";
            this.radioButton59.UseVisualStyleBackColor = true;
            // 
            // radioButton60
            // 
            this.radioButton60.AutoSize = true;
            this.radioButton60.Location = new System.Drawing.Point(44, 206);
            this.radioButton60.Name = "radioButton60";
            this.radioButton60.Size = new System.Drawing.Size(73, 24);
            this.radioButton60.TabIndex = 87;
            this.radioButton60.TabStop = true;
            this.radioButton60.Text = "string";
            this.radioButton60.UseVisualStyleBackColor = true;
            // 
            // radioButton61
            // 
            this.radioButton61.AutoSize = true;
            this.radioButton61.Location = new System.Drawing.Point(44, 175);
            this.radioButton61.Name = "radioButton61";
            this.radioButton61.Size = new System.Drawing.Size(64, 24);
            this.radioButton61.TabIndex = 86;
            this.radioButton61.TabStop = true;
            this.radioButton61.Text = "byte";
            this.radioButton61.UseVisualStyleBackColor = true;
            // 
            // button21
            // 
            this.button21.Location = new System.Drawing.Point(339, 438);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(140, 38);
            this.button21.TabIndex = 95;
            this.button21.Text = "Далее";
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Click += new System.EventHandler(this.button21_Click);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label23.Location = new System.Drawing.Point(44, 98);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(362, 40);
            this.label23.TabIndex = 94;
            this.label23.Text = "Какой символ используется для обозначения \r\nподключения пространства имен в C#?";
            // 
            // radioButton62
            // 
            this.radioButton62.AutoSize = true;
            this.radioButton62.Location = new System.Drawing.Point(44, 145);
            this.radioButton62.Name = "radioButton62";
            this.radioButton62.Size = new System.Drawing.Size(78, 24);
            this.radioButton62.TabIndex = 93;
            this.radioButton62.TabStop = true;
            this.radioButton62.Text = "import";
            this.radioButton62.UseVisualStyleBackColor = true;
            // 
            // radioButton63
            // 
            this.radioButton63.AutoSize = true;
            this.radioButton63.Location = new System.Drawing.Point(44, 206);
            this.radioButton63.Name = "radioButton63";
            this.radioButton63.Size = new System.Drawing.Size(72, 24);
            this.radioButton63.TabIndex = 92;
            this.radioButton63.TabStop = true;
            this.radioButton63.Text = "using";
            this.radioButton63.UseVisualStyleBackColor = true;
            // 
            // radioButton64
            // 
            this.radioButton64.AutoSize = true;
            this.radioButton64.Location = new System.Drawing.Point(44, 175);
            this.radioButton64.Name = "radioButton64";
            this.radioButton64.Size = new System.Drawing.Size(91, 24);
            this.radioButton64.TabIndex = 91;
            this.radioButton64.TabStop = true;
            this.radioButton64.Text = "connect";
            this.radioButton64.UseVisualStyleBackColor = true;
            // 
            // button22
            // 
            this.button22.Location = new System.Drawing.Point(339, 437);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(140, 38);
            this.button22.TabIndex = 100;
            this.button22.Text = "Далее";
            this.button22.UseVisualStyleBackColor = true;
            this.button22.Click += new System.EventHandler(this.button22_Click);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label24.Location = new System.Drawing.Point(44, 97);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(245, 40);
            this.label24.TabIndex = 99;
            this.label24.Text = "Как правильно обратиться к \r\nэлементу массива по индексу?";
            // 
            // radioButton65
            // 
            this.radioButton65.AutoSize = true;
            this.radioButton65.Location = new System.Drawing.Point(44, 144);
            this.radioButton65.Name = "radioButton65";
            this.radioButton65.Size = new System.Drawing.Size(137, 24);
            this.radioButton65.TabIndex = 98;
            this.radioButton65.TabStop = true;
            this.radioButton65.Text = "numbers.index";
            this.radioButton65.UseVisualStyleBackColor = true;
            // 
            // radioButton66
            // 
            this.radioButton66.AutoSize = true;
            this.radioButton66.Location = new System.Drawing.Point(44, 205);
            this.radioButton66.Name = "radioButton66";
            this.radioButton66.Size = new System.Drawing.Size(141, 24);
            this.radioButton66.TabIndex = 97;
            this.radioButton66.TabStop = true;
            this.radioButton66.Text = "numbers[index]";
            this.radioButton66.UseVisualStyleBackColor = true;
            // 
            // radioButton67
            // 
            this.radioButton67.AutoSize = true;
            this.radioButton67.Location = new System.Drawing.Point(44, 174);
            this.radioButton67.Name = "radioButton67";
            this.radioButton67.Size = new System.Drawing.Size(143, 24);
            this.radioButton67.TabIndex = 96;
            this.radioButton67.TabStop = true;
            this.radioButton67.Text = "numbers(index)";
            this.radioButton67.UseVisualStyleBackColor = true;
            // 
            // button23
            // 
            this.button23.Location = new System.Drawing.Point(339, 437);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(140, 38);
            this.button23.TabIndex = 105;
            this.button23.Text = "Далее";
            this.button23.UseVisualStyleBackColor = true;
            this.button23.Click += new System.EventHandler(this.button23_Click);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label25.Location = new System.Drawing.Point(44, 97);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(432, 40);
            this.label25.TabIndex = 104;
            this.label25.Text = "Как объявить переменную, которая может изменяться \r\nтолько в пределах текущего бл" +
    "ока кода в C#?";
            // 
            // radioButton68
            // 
            this.radioButton68.AutoSize = true;
            this.radioButton68.Location = new System.Drawing.Point(44, 144);
            this.radioButton68.Name = "radioButton68";
            this.radioButton68.Size = new System.Drawing.Size(118, 24);
            this.radioButton68.TabIndex = 103;
            this.radioButton68.TabStop = true;
            this.radioButton68.Text = "volatile int x;";
            this.radioButton68.UseVisualStyleBackColor = true;
            // 
            // radioButton69
            // 
            this.radioButton69.AutoSize = true;
            this.radioButton69.Location = new System.Drawing.Point(44, 204);
            this.radioButton69.Name = "radioButton69";
            this.radioButton69.Size = new System.Drawing.Size(108, 24);
            this.radioButton69.TabIndex = 102;
            this.radioButton69.TabStop = true;
            this.radioButton69.Text = "static int x;";
            this.radioButton69.UseVisualStyleBackColor = true;
            // 
            // radioButton70
            // 
            this.radioButton70.AutoSize = true;
            this.radioButton70.Location = new System.Drawing.Point(44, 174);
            this.radioButton70.Name = "radioButton70";
            this.radioButton70.Size = new System.Drawing.Size(66, 24);
            this.radioButton70.TabIndex = 101;
            this.radioButton70.TabStop = true;
            this.radioButton70.Text = "int x;";
            this.radioButton70.UseVisualStyleBackColor = true;
            // 
            // button24
            // 
            this.button24.Location = new System.Drawing.Point(339, 437);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(140, 38);
            this.button24.TabIndex = 110;
            this.button24.Text = "Далее";
            this.button24.UseVisualStyleBackColor = true;
            this.button24.Click += new System.EventHandler(this.button24_Click);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label26.Location = new System.Drawing.Point(44, 98);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(272, 20);
            this.label26.TabIndex = 109;
            this.label26.Text = "Как обработать исключение в C#?";
            // 
            // radioButton71
            // 
            this.radioButton71.AutoSize = true;
            this.radioButton71.Location = new System.Drawing.Point(44, 144);
            this.radioButton71.Name = "radioButton71";
            this.radioButton71.Size = new System.Drawing.Size(130, 24);
            this.radioButton71.TabIndex = 108;
            this.radioButton71.TabStop = true;
            this.radioButton71.Text = "try { } catch { }";
            this.radioButton71.UseVisualStyleBackColor = true;
            // 
            // radioButton72
            // 
            this.radioButton72.AutoSize = true;
            this.radioButton72.Location = new System.Drawing.Point(44, 204);
            this.radioButton72.Name = "radioButton72";
            this.radioButton72.Size = new System.Drawing.Size(138, 24);
            this.radioButton72.TabIndex = 107;
            this.radioButton72.TabStop = true;
            this.radioButton72.Text = "try { } except { }";
            this.radioButton72.UseVisualStyleBackColor = true;
            // 
            // radioButton73
            // 
            this.radioButton73.AutoSize = true;
            this.radioButton73.Location = new System.Drawing.Point(44, 174);
            this.radioButton73.Name = "radioButton73";
            this.radioButton73.Size = new System.Drawing.Size(230, 24);
            this.radioButton73.TabIndex = 106;
            this.radioButton73.TabStop = true;
            this.radioButton73.Text = "try { } catch(Exception ex) { }";
            this.radioButton73.UseVisualStyleBackColor = true;
            // 
            // button25
            // 
            this.button25.Location = new System.Drawing.Point(339, 190);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(140, 38);
            this.button25.TabIndex = 115;
            this.button25.Text = "Далее";
            this.button25.UseVisualStyleBackColor = true;
            this.button25.Click += new System.EventHandler(this.button25_Click);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label27.Location = new System.Drawing.Point(44, 98);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(456, 40);
            this.label27.TabIndex = 114;
            this.label27.Text = "Какой символ используется для объединения строк в C#?\r\n*введите ТОЛЬКО ОДИН симво" +
    "л";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(48, 158);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(431, 26);
            this.textBox1.TabIndex = 116;
            // 
            // button26
            // 
            this.button26.Location = new System.Drawing.Point(339, 437);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(140, 38);
            this.button26.TabIndex = 115;
            this.button26.Text = "Далее";
            this.button26.UseVisualStyleBackColor = true;
            this.button26.Click += new System.EventHandler(this.button26_Click);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label28.Location = new System.Drawing.Point(44, 98);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(291, 40);
            this.label28.TabIndex = 114;
            this.label28.Text = "Какой тип данных используется для \r\nхранения дробных чисел в C#?";
            // 
            // radioButton74
            // 
            this.radioButton74.AutoSize = true;
            this.radioButton74.Location = new System.Drawing.Point(44, 144);
            this.radioButton74.Name = "radioButton74";
            this.radioButton74.Size = new System.Drawing.Size(73, 24);
            this.radioButton74.TabIndex = 113;
            this.radioButton74.TabStop = true;
            this.radioButton74.Text = "string";
            this.radioButton74.UseVisualStyleBackColor = true;
            // 
            // radioButton75
            // 
            this.radioButton75.AutoSize = true;
            this.radioButton75.Location = new System.Drawing.Point(44, 204);
            this.radioButton75.Name = "radioButton75";
            this.radioButton75.Size = new System.Drawing.Size(60, 24);
            this.radioButton75.TabIndex = 112;
            this.radioButton75.TabStop = true;
            this.radioButton75.Text = "real";
            this.radioButton75.UseVisualStyleBackColor = true;
            // 
            // radioButton76
            // 
            this.radioButton76.AutoSize = true;
            this.radioButton76.Location = new System.Drawing.Point(44, 174);
            this.radioButton76.Name = "radioButton76";
            this.radioButton76.Size = new System.Drawing.Size(82, 24);
            this.radioButton76.TabIndex = 111;
            this.radioButton76.TabStop = true;
            this.radioButton76.Text = "double";
            this.radioButton76.UseVisualStyleBackColor = true;
            // 
            // button27
            // 
            this.button27.Location = new System.Drawing.Point(339, 188);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(140, 38);
            this.button27.TabIndex = 120;
            this.button27.Text = "Далее";
            this.button27.UseVisualStyleBackColor = true;
            this.button27.Click += new System.EventHandler(this.button27_Click);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label29.Location = new System.Drawing.Point(44, 98);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(318, 40);
            this.label29.TabIndex = 119;
            this.label29.Text = "Как объявить делегат в C#?\r\n*вместо <...> вставьте пропущенный код";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(48, 156);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(431, 26);
            this.textBox2.TabIndex = 121;
            this.textBox2.Text = "<...> MyDelegate();";
            // 
            // button28
            // 
            this.button28.Location = new System.Drawing.Point(339, 437);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(140, 38);
            this.button28.TabIndex = 120;
            this.button28.Text = "Далее";
            this.button28.UseVisualStyleBackColor = true;
            this.button28.Click += new System.EventHandler(this.button28_Click);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label30.Location = new System.Drawing.Point(44, 98);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(256, 20);
            this.label30.TabIndex = 119;
            this.label30.Text = "Как объявить пустую структуру?";
            // 
            // radioButton77
            // 
            this.radioButton77.AutoSize = true;
            this.radioButton77.Location = new System.Drawing.Point(44, 144);
            this.radioButton77.Name = "radioButton77";
            this.radioButton77.Size = new System.Drawing.Size(159, 24);
            this.radioButton77.TabIndex = 118;
            this.radioButton77.TabStop = true;
            this.radioButton77.Text = "struct MyStruct { }";
            this.radioButton77.UseVisualStyleBackColor = true;
            // 
            // radioButton78
            // 
            this.radioButton78.AutoSize = true;
            this.radioButton78.Location = new System.Drawing.Point(44, 204);
            this.radioButton78.Name = "radioButton78";
            this.radioButton78.Size = new System.Drawing.Size(155, 24);
            this.radioButton78.TabIndex = 117;
            this.radioButton78.TabStop = true;
            this.radioButton78.Text = "class MyStruct { }";
            this.radioButton78.UseVisualStyleBackColor = true;
            // 
            // radioButton79
            // 
            this.radioButton79.AutoSize = true;
            this.radioButton79.Location = new System.Drawing.Point(44, 174);
            this.radioButton79.Name = "radioButton79";
            this.radioButton79.Size = new System.Drawing.Size(181, 24);
            this.radioButton79.TabIndex = 116;
            this.radioButton79.TabStop = true;
            this.radioButton79.Text = "interface MyStruct { }";
            this.radioButton79.UseVisualStyleBackColor = true;
            // 
            // button29
            // 
            this.button29.Location = new System.Drawing.Point(339, 437);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(140, 38);
            this.button29.TabIndex = 125;
            this.button29.Text = "Далее";
            this.button29.UseVisualStyleBackColor = true;
            this.button29.Click += new System.EventHandler(this.button29_Click);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label31.Location = new System.Drawing.Point(44, 98);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(249, 40);
            this.label31.TabIndex = 124;
            this.label31.Text = "Как обратиться к члену класса \r\nиз статического метода в C#?";
            // 
            // radioButton80
            // 
            this.radioButton80.AutoSize = true;
            this.radioButton80.Location = new System.Drawing.Point(44, 144);
            this.radioButton80.Name = "radioButton80";
            this.radioButton80.Size = new System.Drawing.Size(167, 24);
            this.radioButton80.TabIndex = 123;
            this.radioButton80.TabStop = true;
            this.radioButton80.Text = "this.MemberName;";
            this.radioButton80.UseVisualStyleBackColor = true;
            // 
            // radioButton81
            // 
            this.radioButton81.AutoSize = true;
            this.radioButton81.Location = new System.Drawing.Point(44, 204);
            this.radioButton81.Name = "radioButton81";
            this.radioButton81.Size = new System.Drawing.Size(223, 24);
            this.radioButton81.TabIndex = 122;
            this.radioButton81.TabStop = true;
            this.radioButton81.Text = "ClassName.MemberName;";
            this.radioButton81.UseVisualStyleBackColor = true;
            // 
            // radioButton82
            // 
            this.radioButton82.AutoSize = true;
            this.radioButton82.Location = new System.Drawing.Point(44, 174);
            this.radioButton82.Name = "radioButton82";
            this.radioButton82.Size = new System.Drawing.Size(201, 24);
            this.radioButton82.TabIndex = 121;
            this.radioButton82.TabStop = true;
            this.radioButton82.Text = "MyClass.MemberName;";
            this.radioButton82.UseVisualStyleBackColor = true;
            // 
            // button30
            // 
            this.button30.Location = new System.Drawing.Point(339, 437);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(140, 38);
            this.button30.TabIndex = 130;
            this.button30.Text = "Далее";
            this.button30.UseVisualStyleBackColor = true;
            this.button30.Click += new System.EventHandler(this.button30_Click);
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label32.Location = new System.Drawing.Point(44, 99);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(316, 20);
            this.label32.TabIndex = 129;
            this.label32.Text = "Как объявить абстрактный метод в C#?";
            // 
            // radioButton83
            // 
            this.radioButton83.AutoSize = true;
            this.radioButton83.Location = new System.Drawing.Point(44, 144);
            this.radioButton83.Name = "radioButton83";
            this.radioButton83.Size = new System.Drawing.Size(235, 24);
            this.radioButton83.TabIndex = 128;
            this.radioButton83.TabStop = true;
            this.radioButton83.Text = "virtual void MethodName() { }";
            this.radioButton83.UseVisualStyleBackColor = true;
            // 
            // radioButton84
            // 
            this.radioButton84.AutoSize = true;
            this.radioButton84.Location = new System.Drawing.Point(44, 204);
            this.radioButton84.Name = "radioButton84";
            this.radioButton84.Size = new System.Drawing.Size(238, 24);
            this.radioButton84.TabIndex = 127;
            this.radioButton84.TabStop = true;
            this.radioButton84.Text = "void MethodName() abstract;";
            this.radioButton84.UseVisualStyleBackColor = true;
            // 
            // radioButton85
            // 
            this.radioButton85.AutoSize = true;
            this.radioButton85.Location = new System.Drawing.Point(44, 174);
            this.radioButton85.Name = "radioButton85";
            this.radioButton85.Size = new System.Drawing.Size(238, 24);
            this.radioButton85.TabIndex = 126;
            this.radioButton85.TabStop = true;
            this.radioButton85.Text = "abstract void MethodName();";
            this.radioButton85.UseVisualStyleBackColor = true;
            // 
            // button31
            // 
            this.button31.Location = new System.Drawing.Point(339, 436);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(140, 38);
            this.button31.TabIndex = 135;
            this.button31.Text = "Далее";
            this.button31.UseVisualStyleBackColor = true;
            this.button31.Click += new System.EventHandler(this.button31_Click);
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label33.Location = new System.Drawing.Point(44, 99);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(429, 40);
            this.label33.TabIndex = 134;
            this.label33.Text = "Какое ключевое слово используется для прерывания \r\nвыполнения цикла и перехода к " +
    "следующей итерации?";
            // 
            // radioButton86
            // 
            this.radioButton86.AutoSize = true;
            this.radioButton86.Location = new System.Drawing.Point(44, 143);
            this.radioButton86.Name = "radioButton86";
            this.radioButton86.Size = new System.Drawing.Size(76, 24);
            this.radioButton86.TabIndex = 133;
            this.radioButton86.TabStop = true;
            this.radioButton86.Text = "return";
            this.radioButton86.UseVisualStyleBackColor = true;
            // 
            // radioButton87
            // 
            this.radioButton87.AutoSize = true;
            this.radioButton87.Location = new System.Drawing.Point(44, 203);
            this.radioButton87.Name = "radioButton87";
            this.radioButton87.Size = new System.Drawing.Size(74, 24);
            this.radioButton87.TabIndex = 132;
            this.radioButton87.TabStop = true;
            this.radioButton87.Text = "break";
            this.radioButton87.UseVisualStyleBackColor = true;
            // 
            // radioButton88
            // 
            this.radioButton88.AutoSize = true;
            this.radioButton88.Location = new System.Drawing.Point(44, 173);
            this.radioButton88.Name = "radioButton88";
            this.radioButton88.Size = new System.Drawing.Size(95, 24);
            this.radioButton88.TabIndex = 131;
            this.radioButton88.TabStop = true;
            this.radioButton88.Text = "continue";
            this.radioButton88.UseVisualStyleBackColor = true;
            // 
            // label34
            // 
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label34.Location = new System.Drawing.Point(14, 15);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(298, 35);
            this.label34.TabIndex = 2;
            this.label34.Text = "Тестирование по ЯП C#\r\n";
            // 
            // label35
            // 
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label35.Location = new System.Drawing.Point(14, 50);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(298, 35);
            this.label35.TabIndex = 3;
            this.label35.Text = "Ваш результат: count/30";
            // 
            // button32
            // 
            this.button32.Location = new System.Drawing.Point(351, 508);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(153, 43);
            this.button32.TabIndex = 4;
            this.button32.Text = "Выход";
            this.button32.UseVisualStyleBackColor = true;
            this.button32.Click += new System.EventHandler(this.button32_Click);
            // 
            // button33
            // 
            this.button33.Location = new System.Drawing.Point(351, 459);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(153, 43);
            this.button33.TabIndex = 5;
            this.button33.Text = "Начать заново";
            this.button33.UseVisualStyleBackColor = true;
            this.button33.Click += new System.EventHandler(this.button33_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(554, 629);
            this.Controls.Add(this.tabControl1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Тест";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            this.tabPage8.ResumeLayout(false);
            this.tabPage8.PerformLayout();
            this.tabPage9.ResumeLayout(false);
            this.tabPage9.PerformLayout();
            this.tabPage10.ResumeLayout(false);
            this.tabPage10.PerformLayout();
            this.tabPage11.ResumeLayout(false);
            this.tabPage11.PerformLayout();
            this.tabPage12.ResumeLayout(false);
            this.tabPage12.PerformLayout();
            this.tabPage13.ResumeLayout(false);
            this.tabPage13.PerformLayout();
            this.tabPage14.ResumeLayout(false);
            this.tabPage14.PerformLayout();
            this.tabPage15.ResumeLayout(false);
            this.tabPage15.PerformLayout();
            this.tabPage16.ResumeLayout(false);
            this.tabPage16.PerformLayout();
            this.tabPage17.ResumeLayout(false);
            this.tabPage17.PerformLayout();
            this.tabPage18.ResumeLayout(false);
            this.tabPage18.PerformLayout();
            this.tabPage19.ResumeLayout(false);
            this.tabPage19.PerformLayout();
            this.tabPage20.ResumeLayout(false);
            this.tabPage20.PerformLayout();
            this.tabPage21.ResumeLayout(false);
            this.tabPage21.PerformLayout();
            this.tabPage22.ResumeLayout(false);
            this.tabPage22.PerformLayout();
            this.tabPage23.ResumeLayout(false);
            this.tabPage23.PerformLayout();
            this.tabPage24.ResumeLayout(false);
            this.tabPage24.PerformLayout();
            this.tabPage25.ResumeLayout(false);
            this.tabPage25.PerformLayout();
            this.tabPage26.ResumeLayout(false);
            this.tabPage26.PerformLayout();
            this.tabPage27.ResumeLayout(false);
            this.tabPage27.PerformLayout();
            this.tabPage28.ResumeLayout(false);
            this.tabPage28.PerformLayout();
            this.tabPage29.ResumeLayout(false);
            this.tabPage29.PerformLayout();
            this.tabPage30.ResumeLayout(false);
            this.tabPage30.PerformLayout();
            this.tabPage31.ResumeLayout(false);
            this.tabPage31.PerformLayout();
            this.tabPage32.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.TabPage tabPage10;
        private System.Windows.Forms.TabPage tabPage11;
        private System.Windows.Forms.TabPage tabPage12;
        private System.Windows.Forms.TabPage tabPage13;
        private System.Windows.Forms.TabPage tabPage14;
        private System.Windows.Forms.TabPage tabPage15;
        private System.Windows.Forms.TabPage tabPage16;
        private System.Windows.Forms.TabPage tabPage17;
        private System.Windows.Forms.TabPage tabPage18;
        private System.Windows.Forms.TabPage tabPage19;
        private System.Windows.Forms.TabPage tabPage20;
        private System.Windows.Forms.TabPage tabPage21;
        private System.Windows.Forms.TabPage tabPage22;
        private System.Windows.Forms.TabPage tabPage23;
        private System.Windows.Forms.TabPage tabPage24;
        private System.Windows.Forms.TabPage tabPage25;
        private System.Windows.Forms.TabPage tabPage26;
        private System.Windows.Forms.TabPage tabPage27;
        private System.Windows.Forms.TabPage tabPage28;
        private System.Windows.Forms.TabPage tabPage29;
        private System.Windows.Forms.TabPage tabPage30;
        private System.Windows.Forms.TabPage tabPage31;
        private System.Windows.Forms.TabPage tabPage32;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.RadioButton radioButton7;
        private System.Windows.Forms.RadioButton radioButton8;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RadioButton radioButton10;
        private System.Windows.Forms.RadioButton radioButton11;
        private System.Windows.Forms.RadioButton radioButton12;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.RadioButton radioButton9;
        private System.Windows.Forms.RadioButton radioButton13;
        private System.Windows.Forms.RadioButton radioButton14;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.RadioButton radioButton15;
        private System.Windows.Forms.RadioButton radioButton16;
        private System.Windows.Forms.RadioButton radioButton17;
        private System.Windows.Forms.RadioButton radioButton21;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.RadioButton radioButton18;
        private System.Windows.Forms.RadioButton radioButton19;
        private System.Windows.Forms.RadioButton radioButton20;
        private System.Windows.Forms.RadioButton radioButton22;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.RadioButton radioButton23;
        private System.Windows.Forms.RadioButton radioButton24;
        private System.Windows.Forms.RadioButton radioButton25;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.RadioButton radioButton27;
        private System.Windows.Forms.RadioButton radioButton28;
        private System.Windows.Forms.RadioButton radioButton29;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.RadioButton radioButton26;
        private System.Windows.Forms.RadioButton radioButton30;
        private System.Windows.Forms.RadioButton radioButton31;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.RadioButton radioButton32;
        private System.Windows.Forms.RadioButton radioButton33;
        private System.Windows.Forms.RadioButton radioButton34;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.RadioButton radioButton35;
        private System.Windows.Forms.RadioButton radioButton36;
        private System.Windows.Forms.RadioButton radioButton37;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.RadioButton radioButton38;
        private System.Windows.Forms.RadioButton radioButton39;
        private System.Windows.Forms.RadioButton radioButton40;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.RadioButton radioButton41;
        private System.Windows.Forms.RadioButton radioButton42;
        private System.Windows.Forms.RadioButton radioButton43;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.RadioButton radioButton44;
        private System.Windows.Forms.RadioButton radioButton45;
        private System.Windows.Forms.RadioButton radioButton46;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.RadioButton radioButton47;
        private System.Windows.Forms.RadioButton radioButton48;
        private System.Windows.Forms.RadioButton radioButton49;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.RadioButton radioButton50;
        private System.Windows.Forms.RadioButton radioButton51;
        private System.Windows.Forms.RadioButton radioButton52;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.RadioButton radioButton53;
        private System.Windows.Forms.RadioButton radioButton54;
        private System.Windows.Forms.RadioButton radioButton55;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.RadioButton radioButton56;
        private System.Windows.Forms.RadioButton radioButton57;
        private System.Windows.Forms.RadioButton radioButton58;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.RadioButton radioButton59;
        private System.Windows.Forms.RadioButton radioButton60;
        private System.Windows.Forms.RadioButton radioButton61;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.RadioButton radioButton62;
        private System.Windows.Forms.RadioButton radioButton63;
        private System.Windows.Forms.RadioButton radioButton64;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.RadioButton radioButton65;
        private System.Windows.Forms.RadioButton radioButton66;
        private System.Windows.Forms.RadioButton radioButton67;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.RadioButton radioButton68;
        private System.Windows.Forms.RadioButton radioButton69;
        private System.Windows.Forms.RadioButton radioButton70;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.RadioButton radioButton71;
        private System.Windows.Forms.RadioButton radioButton72;
        private System.Windows.Forms.RadioButton radioButton73;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.RadioButton radioButton74;
        private System.Windows.Forms.RadioButton radioButton75;
        private System.Windows.Forms.RadioButton radioButton76;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.RadioButton radioButton77;
        private System.Windows.Forms.RadioButton radioButton78;
        private System.Windows.Forms.RadioButton radioButton79;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.RadioButton radioButton80;
        private System.Windows.Forms.RadioButton radioButton81;
        private System.Windows.Forms.RadioButton radioButton82;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.RadioButton radioButton83;
        private System.Windows.Forms.RadioButton radioButton84;
        private System.Windows.Forms.RadioButton radioButton85;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.RadioButton radioButton86;
        private System.Windows.Forms.RadioButton radioButton87;
        private System.Windows.Forms.RadioButton radioButton88;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button33;
    }
}

